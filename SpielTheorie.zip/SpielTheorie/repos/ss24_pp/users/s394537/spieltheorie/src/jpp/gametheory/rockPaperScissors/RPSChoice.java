package jpp.gametheory.rockPaperScissors;

import jpp.gametheory.generic.IChoice;

public enum
RPSChoice implements IChoice {
    ROCK, PAPER, SCISSORS
}
